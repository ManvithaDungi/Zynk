"use client"

import { useState, useEffect } from "react"
import { Link } from "react-router-dom"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
} from "recharts"
import "./AnalyticsFilter.css"

const AnalyticsFilter = () => {
  const [analyticsData, setAnalyticsData] = useState({})
  const [filters, setFilters] = useState({
    dateRange: "last30days",
    category: "all",
    author: "all",
    engagement: "all",
  })
  const [loading, setLoading] = useState(false)

  const COLORS = ["#3b82f6", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6", "#06b6d4"]

  useEffect(() => {
    fetchAnalyticsData()
  }, [filters])

  const fetchAnalyticsData = async () => {
    setLoading(true)
    try {
      const queryParams = new URLSearchParams(filters).toString()
      const response = await fetch(`/api/analytics-filter/data?${queryParams}`)
      const data = await response.json()
      setAnalyticsData(data)
    } catch (error) {
      console.error("Error fetching analytics:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleFilterChange = (filterType, value) => {
    setFilters((prev) => ({ ...prev, [filterType]: value }))
  }

  const engagementData = [
    { name: "Views", value: analyticsData.totalViews || 0 },
    { name: "Likes", value: analyticsData.totalLikes || 0 },
    { name: "Comments", value: analyticsData.totalComments || 0 },
    { name: "Shares", value: analyticsData.totalShares || 0 },
  ]

  const categoryData = analyticsData.categoryBreakdown || []
  const dailyEngagement = analyticsData.dailyEngagement || []
  const topContributors = analyticsData.topContributors || []

  return (
    <div className="analytics-filter">
      <div className="container">
        <header className="page-header">
          <Link to="/" className="back-btn">
            ← Back to Dashboard
          </Link>
          <div className="header-content">
            <div className="header-icon">📊</div>
            <h1>Analytics Dashboard</h1>
            <p>View detailed insights and trends from your event data</p>
          </div>
        </header>

        <div className="analytics-filters">
          <div className="filter-group">
            <label>Date Range</label>
            <select value={filters.dateRange} onChange={(e) => handleFilterChange("dateRange", e.target.value)}>
              <option value="last7days">Last 7 Days</option>
              <option value="last30days">Last 30 Days</option>
              <option value="last90days">Last 90 Days</option>
              <option value="lastyear">Last Year</option>
              <option value="custom">Custom Range</option>
            </select>
          </div>

          <div className="filter-group">
            <label>Category</label>
            <select value={filters.category} onChange={(e) => handleFilterChange("category", e.target.value)}>
              <option value="all">All Categories</option>
              <option value="highlights">Event Highlights</option>
              <option value="candid">Candid Moments</option>
              <option value="group">Group Photos</option>
              <option value="venue">Venue Shots</option>
            </select>
          </div>

          <div className="filter-group">
            <label>Author</label>
            <select value={filters.author} onChange={(e) => handleFilterChange("author", e.target.value)}>
              <option value="all">All Authors</option>
              <option value="organizers">Organizers Only</option>
              <option value="attendees">Attendees Only</option>
              <option value="photographers">Photographers</option>
            </select>
          </div>

          <div className="filter-group">
            <label>Engagement Level</label>
            <select value={filters.engagement} onChange={(e) => handleFilterChange("engagement", e.target.value)}>
              <option value="all">All Levels</option>
              <option value="high">High Engagement</option>
              <option value="medium">Medium Engagement</option>
              <option value="low">Low Engagement</option>
            </select>
          </div>
        </div>

        {loading ? (
          <div className="loading-state">
            <div className="spinner"></div>
            <p>Loading analytics data...</p>
          </div>
        ) : (
          <div className="analytics-content">
            <div className="stats-overview">
              <div className="stat-card">
                <div className="stat-icon">📸</div>
                <div className="stat-info">
                  <h3>{analyticsData.totalMemories || 0}</h3>
                  <p>Total Memories</p>
                  <span className="stat-change positive">+12% from last period</span>
                </div>
              </div>
              <div className="stat-card">
                <div className="stat-icon">👁️</div>
                <div className="stat-info">
                  <h3>{analyticsData.totalViews || 0}</h3>
                  <p>Total Views</p>
                  <span className="stat-change positive">+8% from last period</span>
                </div>
              </div>
              <div className="stat-card">
                <div className="stat-icon">❤️</div>
                <div className="stat-info">
                  <h3>{analyticsData.totalLikes || 0}</h3>
                  <p>Total Likes</p>
                  <span className="stat-change positive">+15% from last period</span>
                </div>
              </div>
              <div className="stat-card">
                <div className="stat-icon">💬</div>
                <div className="stat-info">
                  <h3>{analyticsData.totalComments || 0}</h3>
                  <p>Total Comments</p>
                  <span className="stat-change negative">-3% from last period</span>
                </div>
              </div>
            </div>

            <div className="charts-grid">
              <div className="chart-container">
                <h3>Daily Engagement Trends</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={dailyEngagement}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Line type="monotone" dataKey="views" stroke="#3b82f6" strokeWidth={2} />
                    <Line type="monotone" dataKey="likes" stroke="#10b981" strokeWidth={2} />
                    <Line type="monotone" dataKey="comments" stroke="#f59e0b" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </div>

              <div className="chart-container">
                <h3>Category Distribution</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={categoryData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {categoryData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>

              <div className="chart-container">
                <h3>Top Contributors</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={topContributors}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="contributions" fill="#8b5cf6" />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              <div className="chart-container">
                <h3>Engagement Metrics</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={engagementData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="value" fill="#06b6d4" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="insights-section">
              <h3>Key Insights</h3>
              <div className="insights-grid">
                <div className="insight-card">
                  <div className="insight-icon">🔥</div>
                  <div className="insight-content">
                    <h4>Peak Engagement Time</h4>
                    <p>Most activity occurs between 7-9 PM on weekends</p>
                  </div>
                </div>
                <div className="insight-card">
                  <div className="insight-icon">📈</div>
                  <div className="insight-content">
                    <h4>Growing Categories</h4>
                    <p>Group Photos and Candid Moments showing 25% growth</p>
                  </div>
                </div>
                <div className="insight-card">
                  <div className="insight-icon">👥</div>
                  <div className="insight-content">
                    <h4>Active Contributors</h4>
                    <p>15% of users contribute 80% of the content</p>
                  </div>
                </div>
                <div className="insight-card">
                  <div className="insight-icon">⭐</div>
                  <div className="insight-content">
                    <h4>Quality Score</h4>
                    <p>Average memory rating is 4.2/5 stars</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

export default AnalyticsFilter
