"use client"

import { useState, useEffect } from "react"
import { Link } from "react-router-dom"
import "./ExportReport.css"

const ExportReport = () => {
  const [reportConfig, setReportConfig] = useState({
    reportType: "summary",
    dateRange: "last30days",
    includeImages: true,
    includeAnalytics: true,
    includeComments: false,
    format: "pdf",
    categories: [],
    authors: [],
  })
  const [availableCategories, setAvailableCategories] = useState([])
  const [availableAuthors, setAvailableAuthors] = useState([])
  const [reportHistory, setReportHistory] = useState([])
  const [generating, setGenerating] = useState(false)

  useEffect(() => {
    fetchReportOptions()
    fetchReportHistory()
  }, [])

  const fetchReportOptions = async () => {
    try {
      const response = await fetch("/api/export-report/options")
      const data = await response.json()
      setAvailableCategories(data.categories || [])
      setAvailableAuthors(data.authors || [])
    } catch (error) {
      console.error("Error fetching report options:", error)
    }
  }

  const fetchReportHistory = async () => {
    try {
      const response = await fetch("/api/export-report/history")
      const data = await response.json()
      setReportHistory(data)
    } catch (error) {
      console.error("Error fetching report history:", error)
    }
  }

  const handleConfigChange = (field, value) => {
    setReportConfig((prev) => ({ ...prev, [field]: value }))
  }

  const handleArrayToggle = (field, value) => {
    setReportConfig((prev) => ({
      ...prev,
      [field]: prev[field].includes(value) ? prev[field].filter((item) => item !== value) : [...prev[field], value],
    }))
  }

  const generateReport = async () => {
    setGenerating(true)
    try {
      const response = await fetch("/api/export-report/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(reportConfig),
      })

      if (response.ok) {
        const blob = await response.blob()
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement("a")
        a.href = url
        a.download = `event-report-${Date.now()}.${reportConfig.format}`
        document.body.appendChild(a)
        a.click()
        window.URL.revokeObjectURL(url)
        document.body.removeChild(a)

        alert("Report generated and downloaded successfully!")
        fetchReportHistory()
      }
    } catch (error) {
      console.error("Error generating report:", error)
      alert("Error generating report")
    } finally {
      setGenerating(false)
    }
  }

  const downloadPreviousReport = async (reportId) => {
    try {
      const response = await fetch(`/api/export-report/download/${reportId}`)
      if (response.ok) {
        const blob = await response.blob()
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement("a")
        a.href = url
        a.download = `previous-report-${reportId}.pdf`
        document.body.appendChild(a)
        a.click()
        window.URL.revokeObjectURL(url)
        document.body.removeChild(a)
      }
    } catch (error) {
      console.error("Error downloading report:", error)
      alert("Error downloading report")
    }
  }

  const getReportTypeDescription = (type) => {
    switch (type) {
      case "summary":
        return "Overview of key metrics and highlights"
      case "detailed":
        return "Comprehensive analysis with all data points"
      case "analytics":
        return "Focus on engagement and performance metrics"
      case "content":
        return "Memory catalog with descriptions and metadata"
      default:
        return ""
    }
  }

  return (
    <div className="export-report">
      <div className="container">
        <header className="page-header">
          <Link to="/" className="back-btn">
            ← Back to Dashboard
          </Link>
          <div className="header-content">
            <div className="header-icon">📥</div>
            <h1>Export & Reports</h1>
            <p>Generate and download comprehensive event reports</p>
          </div>
        </header>

        <div className="export-content">
          <div className="report-config">
            <h3>Report Configuration</h3>

            <div className="config-section">
              <h4>Report Type</h4>
              <div className="radio-group">
                {["summary", "detailed", "analytics", "content"].map((type) => (
                  <label key={type} className="radio-option">
                    <input
                      type="radio"
                      name="reportType"
                      value={type}
                      checked={reportConfig.reportType === type}
                      onChange={(e) => handleConfigChange("reportType", e.target.value)}
                    />
                    <div className="radio-content">
                      <span className="radio-title">{type.charAt(0).toUpperCase() + type.slice(1)} Report</span>
                      <span className="radio-description">{getReportTypeDescription(type)}</span>
                    </div>
                  </label>
                ))}
              </div>
            </div>

            <div className="config-section">
              <h4>Date Range</h4>
              <select
                value={reportConfig.dateRange}
                onChange={(e) => handleConfigChange("dateRange", e.target.value)}
                className="form-select"
              >
                <option value="last7days">Last 7 Days</option>
                <option value="last30days">Last 30 Days</option>
                <option value="last90days">Last 90 Days</option>
                <option value="lastyear">Last Year</option>
                <option value="all">All Time</option>
              </select>
            </div>

            <div className="config-section">
              <h4>Export Format</h4>
              <div className="format-options">
                {["pdf", "csv", "json", "xlsx"].map((format) => (
                  <button
                    key={format}
                    className={`format-btn ${reportConfig.format === format ? "active" : ""}`}
                    onClick={() => handleConfigChange("format", format)}
                  >
                    {format.toUpperCase()}
                  </button>
                ))}
              </div>
            </div>

            <div className="config-section">
              <h4>Include Options</h4>
              <div className="checkbox-group">
                <label className="checkbox-option">
                  <input
                    type="checkbox"
                    checked={reportConfig.includeImages}
                    onChange={(e) => handleConfigChange("includeImages", e.target.checked)}
                  />
                  <span>Include Images</span>
                </label>
                <label className="checkbox-option">
                  <input
                    type="checkbox"
                    checked={reportConfig.includeAnalytics}
                    onChange={(e) => handleConfigChange("includeAnalytics", e.target.checked)}
                  />
                  <span>Include Analytics Data</span>
                </label>
                <label className="checkbox-option">
                  <input
                    type="checkbox"
                    checked={reportConfig.includeComments}
                    onChange={(e) => handleConfigChange("includeComments", e.target.checked)}
                  />
                  <span>Include Comments & Feedback</span>
                </label>
              </div>
            </div>

            <div className="config-section">
              <h4>Filter by Categories</h4>
              <div className="filter-tags">
                {availableCategories.map((category) => (
                  <button
                    key={category}
                    className={`filter-tag ${reportConfig.categories.includes(category) ? "active" : ""}`}
                    onClick={() => handleArrayToggle("categories", category)}
                  >
                    {category}
                  </button>
                ))}
              </div>
            </div>

            <div className="config-section">
              <h4>Filter by Authors</h4>
              <div className="filter-tags">
                {availableAuthors.map((author) => (
                  <button
                    key={author}
                    className={`filter-tag ${reportConfig.authors.includes(author) ? "active" : ""}`}
                    onClick={() => handleArrayToggle("authors", author)}
                  >
                    {author}
                  </button>
                ))}
              </div>
            </div>

            <div className="generate-section">
              <button onClick={generateReport} className="btn btn-primary btn-large" disabled={generating}>
                {generating ? (
                  <>
                    <span className="spinner-small"></span>
                    Generating Report...
                  </>
                ) : (
                  <>📥 Generate & Download Report</>
                )}
              </button>
            </div>
          </div>

          <div className="report-history">
            <h3>Report History</h3>
            <div className="history-list">
              {reportHistory.length === 0 ? (
                <div className="empty-state">
                  <div className="empty-icon">📄</div>
                  <p>No reports generated yet</p>
                  <span>Generate your first report to see it here</span>
                </div>
              ) : (
                reportHistory.map((report) => (
                  <div key={report._id} className="history-item">
                    <div className="report-info">
                      <div className="report-title">
                        {report.type.charAt(0).toUpperCase() + report.type.slice(1)} Report
                      </div>
                      <div className="report-meta">
                        <span>Generated: {new Date(report.createdAt).toLocaleDateString()}</span>
                        <span>Format: {report.format.toUpperCase()}</span>
                        <span>Size: {report.fileSize || "N/A"}</span>
                      </div>
                      <div className="report-config-summary">
                        Date Range: {report.dateRange} | Categories: {report.categories?.length || 0} | Authors:{" "}
                        {report.authors?.length || 0}
                      </div>
                    </div>
                    <div className="report-actions">
                      <button onClick={() => downloadPreviousReport(report._id)} className="btn btn-secondary btn-sm">
                        📥 Download
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default ExportReport
