"use client"

import { useState, useEffect } from "react"
import { Link } from "react-router-dom"
import "./HighlightReelBuilder.css"

const HighlightReelBuilder = () => {
  const [memories, setMemories] = useState([]) // Ensure always initialized as array
  const [highlightReel, setHighlightReel] = useState([])
  const [reelTitle, setReelTitle] = useState("")
  const [reelDescription, setReelDescription] = useState("")
  const [loading, setLoading] = useState(false)
  const [fetchingMemories, setFetchingMemories] = useState(true) // Added loading state for memories

  useEffect(() => {
    fetchMemories()
  }, [])

  const fetchMemories = async () => {
    try {
      setFetchingMemories(true) // Set loading state
      const response = await fetch("/api/highlight-reel/memories")
      const data = await response.json()

      if (Array.isArray(data)) {
        setMemories(data)
      } else if (data && Array.isArray(data.memories)) {
        setMemories(data.memories)
      } else if (data && Array.isArray(data.data)) {
        setMemories(data.data)
      } else {
        console.warn("API response is not in expected format:", data)
        setMemories([]) // Fallback to empty array
      }
    } catch (error) {
      console.error("Error fetching memories:", error)
      setMemories([]) // Always set to empty array on error
    } finally {
      setFetchingMemories(false) // Clear loading state
    }
  }

  const addToHighlightReel = (memory) => {
    if (!highlightReel.find((item) => item._id === memory._id)) {
      setHighlightReel([...highlightReel, { ...memory, order: highlightReel.length + 1 }])
    }
  }

  const removeFromHighlightReel = (memoryId) => {
    setHighlightReel(highlightReel.filter((item) => item._id !== memoryId))
  }

  const moveUp = (index) => {
    if (index > 0) {
      const newReel = [...highlightReel]
      ;[newReel[index], newReel[index - 1]] = [newReel[index - 1], newReel[index]]
      setHighlightReel(newReel)
    }
  }

  const moveDown = (index) => {
    if (index < highlightReel.length - 1) {
      const newReel = [...highlightReel]
      ;[newReel[index], newReel[index + 1]] = [newReel[index + 1], newReel[index]]
      setHighlightReel(newReel)
    }
  }

  const saveHighlightReel = async () => {
    if (!reelTitle || highlightReel.length === 0) {
      alert("Please provide a title and add at least one memory")
      return
    }

    setLoading(true)
    try {
      const response = await fetch("/api/highlight-reel/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: reelTitle,
          description: reelDescription,
          memories: highlightReel.map((item, index) => ({ memoryId: item._id, order: index + 1 })),
        }),
      })

      if (response.ok) {
        alert("Highlight reel created successfully!")
        setHighlightReel([])
        setReelTitle("")
        setReelDescription("")
      }
    } catch (error) {
      console.error("Error creating highlight reel:", error)
      alert("Error creating highlight reel")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="highlight-reel-builder">
      <div className="container">
        <header className="page-header">
          <Link to="/" className="back-btn">
            ← Back to Dashboard
          </Link>
          <div className="header-content">
            <div className="header-icon">⭐</div>
            <h1>Highlight Reel Builder</h1>
            <p>Create curated collections of the best event memories</p>
          </div>
        </header>

        <div className="builder-content">
          <div className="memories-panel">
            <h3>Available Memories</h3>
            {fetchingMemories ? (
              <div className="loading-state">Loading memories...</div>
            ) : memories.length === 0 ? (
              <div className="empty-state">
                <p>No memories available. Make sure your backend is running and has sample data.</p>
                <button onClick={fetchMemories} className="btn btn-primary">
                  Retry
                </button>
              </div>
            ) : (
              <div className="memories-grid">
                {memories.map((memory) => (
                  <div key={memory._id} className="memory-card">
                    <img src={memory.imageUrl || "/placeholder.svg"} alt={memory.title} />
                    <div className="memory-info">
                      <h4>{memory.title}</h4>
                      <p>{memory.description}</p>
                      <button
                        onClick={() => addToHighlightReel(memory)}
                        className="btn btn-primary btn-sm"
                        disabled={highlightReel.find((item) => item._id === memory._id)}
                      >
                        {highlightReel.find((item) => item._id === memory._id) ? "Added" : "Add to Reel"}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="reel-panel">
            <div className="reel-header">
              <h3>Highlight Reel ({highlightReel.length} memories)</h3>
              <div className="reel-form">
                <input
                  type="text"
                  placeholder="Reel title"
                  value={reelTitle}
                  onChange={(e) => setReelTitle(e.target.value)}
                  className="form-input"
                />
                <textarea
                  placeholder="Reel description (optional)"
                  value={reelDescription}
                  onChange={(e) => setReelDescription(e.target.value)}
                  className="form-textarea"
                />
              </div>
            </div>

            <div className="reel-list">
              {highlightReel.map((memory, index) => (
                <div key={memory._id} className="reel-item">
                  <div className="reel-order">{index + 1}</div>
                  <img src={memory.imageUrl || "/placeholder.svg"} alt={memory.title} />
                  <div className="reel-info">
                    <h4>{memory.title}</h4>
                    <p>{memory.description}</p>
                  </div>
                  <div className="reel-actions">
                    <button onClick={() => moveUp(index)} disabled={index === 0} className="btn btn-sm">
                      ↑
                    </button>
                    <button
                      onClick={() => moveDown(index)}
                      disabled={index === highlightReel.length - 1}
                      className="btn btn-sm"
                    >
                      ↓
                    </button>
                    <button onClick={() => removeFromHighlightReel(memory._id)} className="btn btn-danger btn-sm">
                      ×
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <div className="reel-footer">
              <button
                onClick={saveHighlightReel}
                className="btn btn-primary"
                disabled={loading || !reelTitle || highlightReel.length === 0}
              >
                {loading ? "Creating..." : "Create Highlight Reel"}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default HighlightReelBuilder
