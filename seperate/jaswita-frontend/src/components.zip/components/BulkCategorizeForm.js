"use client"

import { useState, useEffect } from "react"
import { Link } from "react-router-dom"
import "./BulkCategorizeForm.css"

const BulkCategorizeForm = () => {
  const [memories, setMemories] = useState([]) // Ensure always initialized as array
  const [selectedMemories, setSelectedMemories] = useState([])
  const [categories, setCategories] = useState(["Event Highlights", "Candid Moments", "Group Photos", "Venue Shots"])
  const [tags, setTags] = useState(["fun", "memorable", "beautiful", "exciting", "emotional"])
  const [selectedCategory, setSelectedCategory] = useState("")
  const [selectedTags, setSelectedTags] = useState([])
  const [newCategory, setNewCategory] = useState("")
  const [newTag, setNewTag] = useState("")
  const [loading, setLoading] = useState(false)
  const [fetchingMemories, setFetchingMemories] = useState(true) // Added loading state

  useEffect(() => {
    fetchMemories()
  }, [])

  const fetchMemories = async () => {
    try {
      setFetchingMemories(true) // Set loading state
      const response = await fetch("/api/bulk-categorize/memories")
      const data = await response.json()

      if (Array.isArray(data)) {
        setMemories(data)
      } else if (data && Array.isArray(data.memories)) {
        setMemories(data.memories)
      } else if (data && Array.isArray(data.data)) {
        setMemories(data.data)
      } else {
        console.warn("API response is not in expected format:", data)
        setMemories([]) // Fallback to empty array
      }
    } catch (error) {
      console.error("Error fetching memories:", error)
      setMemories([]) // Always set to empty array on error
    } finally {
      setFetchingMemories(false) // Clear loading state
    }
  }

  const handleMemorySelect = (memoryId) => {
    setSelectedMemories((prev) =>
      prev.includes(memoryId) ? prev.filter((id) => id !== memoryId) : [...prev, memoryId],
    )
  }

  const handleSelectAll = () => {
    setSelectedMemories(memories.map((memory) => memory._id))
  }

  const handleDeselectAll = () => {
    setSelectedMemories([])
  }

  const handleTagToggle = (tag) => {
    setSelectedTags((prev) => (prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]))
  }

  const addNewCategory = () => {
    if (newCategory && !categories.includes(newCategory)) {
      setCategories([...categories, newCategory])
      setNewCategory("")
    }
  }

  const addNewTag = () => {
    if (newTag && !tags.includes(newTag)) {
      setTags([...tags, newTag])
      setNewTag("")
    }
  }

  const handleBulkCategorize = async () => {
    if (selectedMemories.length === 0) {
      alert("Please select at least one memory")
      return
    }

    setLoading(true)
    try {
      const response = await fetch("/api/bulk-categorize/update", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          memoryIds: selectedMemories,
          category: selectedCategory,
          tags: selectedTags,
        }),
      })

      if (response.ok) {
        alert("Memories updated successfully!")
        fetchMemories()
        setSelectedMemories([])
        setSelectedCategory("")
        setSelectedTags([])
      }
    } catch (error) {
      console.error("Error updating memories:", error)
      alert("Error updating memories")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="bulk-categorize">
      <div className="container">
        <header className="page-header">
          <Link to="/" className="back-btn">
            ← Back to Dashboard
          </Link>
          <div className="header-content">
            <div className="header-icon">🏷️</div>
            <h1>Bulk Categorize & Tag Memories</h1>
            <p>Organize multiple memories by assigning categories and tags in bulk</p>
          </div>
        </header>

        <div className="bulk-categorize-content">
          <div className="selection-panel">
            <div className="panel-header">
              <h3>Select Memories ({selectedMemories.length} selected)</h3>
              <div className="selection-actions">
                <button onClick={handleSelectAll} className="btn btn-secondary">
                  Select All
                </button>
                <button onClick={handleDeselectAll} className="btn btn-secondary">
                  Deselect All
                </button>
              </div>
            </div>

            {fetchingMemories ? (
              <div className="loading-state">
                <div className="spinner"></div>
                <p>Loading memories...</p>
              </div>
            ) : memories.length === 0 ? (
              <div className="empty-state">
                <div className="empty-icon">📸</div>
                <p>No memories available</p>
                <span>Make sure your backend is running and has sample data</span>
                <button onClick={fetchMemories} className="btn btn-primary">
                  Retry
                </button>
              </div>
            ) : (
              <div className="memories-grid">
                {memories.map((memory) => (
                  <div
                    key={memory._id}
                    className={`memory-item ${selectedMemories.includes(memory._id) ? "selected" : ""}`}
                    onClick={() => handleMemorySelect(memory._id)}
                  >
                    <div className="memory-checkbox">{selectedMemories.includes(memory._id) && "✓"}</div>
                    <img src={memory.imageUrl || "/placeholder.svg"} alt={memory.title} />
                    <div className="memory-info">
                      <h4>{memory.title}</h4>
                      <p>{memory.description}</p>
                      <div className="memory-meta">
                        <span>By {memory.author}</span>
                        <span>{new Date(memory.createdAt).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="categorization-panel">
            <div className="category-section">
              <h3>Categories</h3>
              <div className="category-options">
                {categories.map((category) => (
                  <label key={category} className="category-option">
                    <input
                      type="radio"
                      name="category"
                      value={category}
                      checked={selectedCategory === category}
                      onChange={(e) => setSelectedCategory(e.target.value)}
                    />
                    <span>{category}</span>
                  </label>
                ))}
              </div>
              <div className="add-category">
                <input
                  type="text"
                  placeholder="Add new category"
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value)}
                />
                <button onClick={addNewCategory} className="btn btn-secondary">
                  Add
                </button>
              </div>
            </div>

            <div className="tags-section">
              <h3>Tags</h3>
              <div className="tags-options">
                {tags.map((tag) => (
                  <label key={tag} className="tag-option">
                    <input type="checkbox" checked={selectedTags.includes(tag)} onChange={() => handleTagToggle(tag)} />
                    <span>{tag}</span>
                  </label>
                ))}
              </div>
              <div className="add-tag">
                <input
                  type="text"
                  placeholder="Add new tag"
                  value={newTag}
                  onChange={(e) => setNewTag(e.target.value)}
                />
                <button onClick={addNewTag} className="btn btn-secondary">
                  Add
                </button>
              </div>
            </div>

            <div className="action-section">
              <button
                onClick={handleBulkCategorize}
                className="btn btn-primary"
                disabled={loading || selectedMemories.length === 0}
              >
                {loading ? "Updating..." : `Update ${selectedMemories.length} Memories`}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default BulkCategorizeForm
